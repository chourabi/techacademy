package com.javainuse.entitys;

public class Produit {

}
